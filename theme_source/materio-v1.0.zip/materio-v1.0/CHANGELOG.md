# Changelog

All notable changes to this template will be documented in this file.

## [1.0] - 2021-08-09

#### Added

- Initial Release
